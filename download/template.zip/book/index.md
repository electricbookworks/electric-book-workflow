---
title: Cover
style: cover
layout: min
---

[![Cover](images/cover.jpg){:.cover}]({{ page.contents }})
{:.cover}
