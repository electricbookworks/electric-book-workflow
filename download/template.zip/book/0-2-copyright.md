---
title: Copyright
style: copyright-page
---

# Copyright
{:.non-printing}

Text © A. N. Author

ISBN (print edition): 9780000000000  
ISBN (reflowable ebook): 9780000000000  

This is your copyright, or imprint, page. Include your own copyright and licensing information here.
