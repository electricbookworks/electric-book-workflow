---
title: Title page
style: title-page
---

The title
{:.title-page-title}

The subtitle
{:.title-page-subtitle}

A. N. Author
{:.title-page-author}

![Publisher logo](images/publisher-logo.jpg)
{:.title-page-logo}
