---
title: Series home
style: home
---

If you're creating one or more books in a series, this index page is a good place to keep information about the books, like basic metadata and marketing copy. It won't be included in the output versions of your books (e.g. the print PDF or epub), but it can be a landing page for a series website.
