# Electric Book Workflow template

This folder contains a template for creating books with the Electric Book Workflow. Replace the text in this file with your own README for your publishing project.

To learn how to use the template, [read the guide](http://electricbookworks.github.io/electric-book-workflow/). The guide is also an example of the workflow in action.
